var annotated_dup =
[
    [ "tao", null, [
      [ "threading", null, [
        [ "internal", null, [
          [ "index_sequence_", "structtao_1_1threading_1_1internal_1_1index__sequence__.html", null ],
          [ "index_sequence_helper_", "structtao_1_1threading_1_1internal_1_1index__sequence__helper__.html", null ],
          [ "index_sequence_helper_< 0U, Next... >", "structtao_1_1threading_1_1internal_1_1index__sequence__helper___3_010_u_00_01_next_8_8_8_01_4.html", null ]
        ] ]
      ] ],
      [ "Drivetrain", "classtao_1_1_drivetrain.html", "classtao_1_1_drivetrain" ],
      [ "DrivetrainProfile", "structtao_1_1_drivetrain_profile.html", "structtao_1_1_drivetrain_profile" ],
      [ "PIDController", "classtao_1_1_p_i_d_controller.html", null ],
      [ "PIDGains", "structtao_1_1_p_i_d_gains.html", "structtao_1_1_p_i_d_gains" ],
      [ "Vector2", "classtao_1_1_vector2.html", "classtao_1_1_vector2" ]
    ] ]
];