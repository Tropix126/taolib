var classtao_1_1_vector2 =
[
    [ "Vector2", "classtao_1_1_vector2.html#a76b488cae66f02da126eafefbc5090d9", null ],
    [ "Vector2", "classtao_1_1_vector2.html#a4b683aa12a50d17113c0ca5456e5d42a", null ],
    [ "Vector2", "classtao_1_1_vector2.html#a18f0d9cf89f39649c63c49d47ffcc9f7", null ],
    [ "get_angle", "classtao_1_1_vector2.html#a3e65ba8e9fa432ffb07a22a22801cc13", null ],
    [ "get_magnitude", "classtao_1_1_vector2.html#afd403d34438c90ce6b9fcb898166c13c", null ],
    [ "get_x", "classtao_1_1_vector2.html#aaa918b115227d1e8aa9b22eead200e3a", null ],
    [ "get_y", "classtao_1_1_vector2.html#abd00ce60254a20edef09154364a6cef8", null ],
    [ "normalized", "classtao_1_1_vector2.html#a911e6a2b0a9087fdd9be7c17ff8c04dd", null ],
    [ "rotated", "classtao_1_1_vector2.html#ae0f8951c3e148e326f728c80038e98b4", null ],
    [ "operator*", "classtao_1_1_vector2.html#a0cae90787028d9a95fa4cacc8ea90c56", null ],
    [ "operator+", "classtao_1_1_vector2.html#a63e74f57546a0537d6fc8eed7ea1ddc9", null ],
    [ "operator-", "classtao_1_1_vector2.html#a0feca9ade3edd654f44ab6073ba3f15f", null ],
    [ "operator/", "classtao_1_1_vector2.html#a13733ffd2601e591203e86b8fccf258c", null ]
];