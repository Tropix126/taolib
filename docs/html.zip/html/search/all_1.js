var searchData=
[
  ['distance_0',['distance',['../classtao_1_1_vector2.html#a84749d146d1715a6e4238d300c4a75fc',1,'tao::Vector2']]],
  ['dot_1',['dot',['../classtao_1_1_vector2.html#a45a264ebf3844c3755760474357257e3',1,'tao::Vector2']]],
  ['drive_2',['drive',['../classtao_1_1_drivetrain.html#a5067680a32f2ad4a7b69c8396fc3fd65',1,'tao::Drivetrain']]],
  ['drive_5fgains_3',['drive_gains',['../structtao_1_1_drivetrain_profile.html#afa6835f2cc761184f88803afff50a719',1,'tao::DrivetrainProfile']]],
  ['drive_5ftolerance_4',['drive_tolerance',['../structtao_1_1_drivetrain_profile.html#ac5069fa60b59631b002b59442690f109',1,'tao::DrivetrainProfile']]],
  ['drivetrain_5',['Drivetrain',['../classtao_1_1_drivetrain.html#aef492840275283a8c78183213f7f11e4',1,'tao::Drivetrain::Drivetrain(vex::motor_group &amp;left_motors, vex::motor_group &amp;right_motors, vex::inertial &amp;IMU, DrivetrainProfile profile)'],['../classtao_1_1_drivetrain.html#a604e19d423fbb4a7655b251c6fc83f89',1,'tao::Drivetrain::Drivetrain(vex::motor_group &amp;left_motors, vex::motor_group &amp;right_motors, DrivetrainProfile profile)'],['../classtao_1_1_drivetrain.html#af27cccd2315a0729c9fa89314312d0c4',1,'tao::Drivetrain::Drivetrain(vex::motor_group &amp;left_motors, vex::motor_group &amp;right_motors, vex::encoder &amp;left_encoder, vex::encoder &amp;right_encoder, vex::inertial &amp;IMU, DrivetrainProfile profile)'],['../classtao_1_1_drivetrain.html#a8358a68227d0aa01d55d29dd99df8e13',1,'tao::Drivetrain::Drivetrain(vex::motor_group &amp;left_motors, vex::motor_group &amp;right_motors, vex::encoder &amp;left_encoder, vex::encoder &amp;right_encoder, DrivetrainProfile profile)'],['../classtao_1_1_drivetrain.html',1,'tao::Drivetrain']]],
  ['drivetrainprofile_6',['DrivetrainProfile',['../structtao_1_1_drivetrain_profile.html',1,'tao']]]
];
