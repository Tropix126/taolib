var searchData=
[
  ['external_5fgear_5fratio_0',['external_gear_ratio',['../structtao_1_1_drivetrain_profile.html#aaf77c4cb93938c67d97d2fc3c89d9502',1,'tao::DrivetrainProfile']]]
];
