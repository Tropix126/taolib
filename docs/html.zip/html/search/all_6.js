var searchData=
[
  ['kd_0',['kD',['../structtao_1_1_p_i_d_gains.html#a86c551d3a88e206485288cf69dd85385',1,'tao::PIDGains']]],
  ['ki_1',['kI',['../structtao_1_1_p_i_d_gains.html#ae0d851ace5410cf72cac1af9a48ebdb1',1,'tao::PIDGains']]],
  ['kp_2',['kP',['../structtao_1_1_p_i_d_gains.html#aa5ee1188c05c7cbca1345d6509592b03',1,'tao::PIDGains']]]
];
