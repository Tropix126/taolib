var searchData=
[
  ['reset_5ftracking_0',['reset_tracking',['../classtao_1_1_drivetrain.html#a11c2137fdf39b18314c341c901a0c81d',1,'tao::Drivetrain']]],
  ['rotated_1',['rotated',['../classtao_1_1_vector2.html#ae0f8951c3e148e326f728c80038e98b4',1,'tao::Vector2']]]
];
