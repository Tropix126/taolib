var searchData=
[
  ['set_5fdrive_5fgains_0',['set_drive_gains',['../classtao_1_1_drivetrain.html#a6d214520c2470c6c052397a091913b31',1,'tao::Drivetrain']]],
  ['set_5fdrive_5ftolerance_1',['set_drive_tolerance',['../classtao_1_1_drivetrain.html#a35ecffb0b5339ea79480373ade5249ef',1,'tao::Drivetrain']]],
  ['set_5fexternal_5fgear_5fratio_2',['set_external_gear_ratio',['../classtao_1_1_drivetrain.html#ac83ee63f438567eddee1e6af5b9488e1',1,'tao::Drivetrain']]],
  ['set_5flookahead_5fdistance_3',['set_lookahead_distance',['../classtao_1_1_drivetrain.html#a5b15ebf8d8817cea28a7c6441cc56def',1,'tao::Drivetrain']]],
  ['set_5fmax_5fdrive_5fvelocity_4',['set_max_drive_velocity',['../classtao_1_1_drivetrain.html#aa8c6855350fce4c249d030ca1a6ac59d',1,'tao::Drivetrain']]],
  ['set_5fmax_5fturn_5fvelocity_5',['set_max_turn_velocity',['../classtao_1_1_drivetrain.html#a5e18ba61ebbe28d5a54af00223416968',1,'tao::Drivetrain']]],
  ['set_5fturn_5fgains_6',['set_turn_gains',['../classtao_1_1_drivetrain.html#a6e2fe02fc1879143d7095f1460ebbcb5',1,'tao::Drivetrain']]],
  ['set_5fturn_5ftolerance_7',['set_turn_tolerance',['../classtao_1_1_drivetrain.html#a32e15c0a3ef58f7e46b83a46ed741b15',1,'tao::Drivetrain']]],
  ['setup_5ftracking_8',['setup_tracking',['../classtao_1_1_drivetrain.html#a446345e28adebd6cce98d0bab3b0f136',1,'tao::Drivetrain']]],
  ['stop_5ftracking_9',['stop_tracking',['../classtao_1_1_drivetrain.html#a2f5d526ef373b69666309afc45c98302',1,'tao::Drivetrain']]]
];
