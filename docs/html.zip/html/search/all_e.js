var searchData=
[
  ['track_5fwidth_0',['track_width',['../structtao_1_1_drivetrain_profile.html#a58a1c1a4f67b7f680c62666fceb7e8fe',1,'tao::DrivetrainProfile']]],
  ['turn_5fgains_1',['turn_gains',['../structtao_1_1_drivetrain_profile.html#aef62c342c2ab3b83f760be19086a6635',1,'tao::DrivetrainProfile']]],
  ['turn_5fto_2',['turn_to',['../classtao_1_1_drivetrain.html#a1721f37994074aa47c7051a01c41b68c',1,'tao::Drivetrain::turn_to(double heading, bool blocking=true)'],['../classtao_1_1_drivetrain.html#a6cf09dd9309e2771d725d5f862b8928a',1,'tao::Drivetrain::turn_to(Vector2 point, bool blocking=true)']]],
  ['turn_5ftolerance_3',['turn_tolerance',['../structtao_1_1_drivetrain_profile.html#aa54721e9d417213b4852e88cbad24855',1,'tao::DrivetrainProfile']]]
];
