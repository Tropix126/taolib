var searchData=
[
  ['turn_5fto_0',['turn_to',['../classtao_1_1_drivetrain.html#a1721f37994074aa47c7051a01c41b68c',1,'tao::Drivetrain::turn_to(double heading, bool blocking=true)'],['../classtao_1_1_drivetrain.html#a6cf09dd9309e2771d725d5f862b8928a',1,'tao::Drivetrain::turn_to(Vector2 point, bool blocking=true)']]]
];
