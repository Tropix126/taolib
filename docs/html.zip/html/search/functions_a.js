var searchData=
[
  ['vector2_0',['Vector2',['../classtao_1_1_vector2.html#a76b488cae66f02da126eafefbc5090d9',1,'tao::Vector2::Vector2(double x, double y)'],['../classtao_1_1_vector2.html#a4b683aa12a50d17113c0ca5456e5d42a',1,'tao::Vector2::Vector2(const Vector2 &amp;v)'],['../classtao_1_1_vector2.html#a18f0d9cf89f39649c63c49d47ffcc9f7',1,'tao::Vector2::Vector2()']]]
];
