var indexSectionsWithContent =
{
  0: "cdeghiklmnoprstvw",
  1: "dipv",
  2: "cdghimnrstv",
  3: "dekltw",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Friends"
};

