var searchData=
[
  ['drive_5fgains_0',['drive_gains',['../structtao_1_1_drivetrain_profile.html#afa6835f2cc761184f88803afff50a719',1,'tao::DrivetrainProfile']]],
  ['drive_5ftolerance_1',['drive_tolerance',['../structtao_1_1_drivetrain_profile.html#ac5069fa60b59631b002b59442690f109',1,'tao::DrivetrainProfile']]]
];
