var searchData=
[
  ['track_5fwidth_0',['track_width',['../structtao_1_1_drivetrain_profile.html#a58a1c1a4f67b7f680c62666fceb7e8fe',1,'tao::DrivetrainProfile']]],
  ['turn_5fgains_1',['turn_gains',['../structtao_1_1_drivetrain_profile.html#aef62c342c2ab3b83f760be19086a6635',1,'tao::DrivetrainProfile']]],
  ['turn_5ftolerance_2',['turn_tolerance',['../structtao_1_1_drivetrain_profile.html#aa54721e9d417213b4852e88cbad24855',1,'tao::DrivetrainProfile']]]
];
