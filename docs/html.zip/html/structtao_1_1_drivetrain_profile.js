var structtao_1_1_drivetrain_profile =
[
    [ "drive_gains", "structtao_1_1_drivetrain_profile.html#afa6835f2cc761184f88803afff50a719", null ],
    [ "drive_tolerance", "structtao_1_1_drivetrain_profile.html#ac5069fa60b59631b002b59442690f109", null ],
    [ "external_gear_ratio", "structtao_1_1_drivetrain_profile.html#aaf77c4cb93938c67d97d2fc3c89d9502", null ],
    [ "lookahead_distance", "structtao_1_1_drivetrain_profile.html#a6b69402bddad0dfa65d9310a8385a86b", null ],
    [ "track_width", "structtao_1_1_drivetrain_profile.html#a58a1c1a4f67b7f680c62666fceb7e8fe", null ],
    [ "turn_gains", "structtao_1_1_drivetrain_profile.html#aef62c342c2ab3b83f760be19086a6635", null ],
    [ "turn_tolerance", "structtao_1_1_drivetrain_profile.html#aa54721e9d417213b4852e88cbad24855", null ],
    [ "wheel_radius", "structtao_1_1_drivetrain_profile.html#a28559268cc05370beeb97ff55086bc0c", null ]
];