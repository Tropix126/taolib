var structtao_1_1_p_i_d_gains =
[
    [ "kD", "structtao_1_1_p_i_d_gains.html#a86c551d3a88e206485288cf69dd85385", null ],
    [ "kI", "structtao_1_1_p_i_d_gains.html#ae0d851ace5410cf72cac1af9a48ebdb1", null ],
    [ "kP", "structtao_1_1_p_i_d_gains.html#aa5ee1188c05c7cbca1345d6509592b03", null ]
];